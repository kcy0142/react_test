import React, { Component } from 'react';

class Button extends Component {

    constructor(props) {
        super(props);
        this.onIncreament=this.onIncreament.bind(this);
        this.onDecrement=this.onDecrement.bind(this);
    }
    
    onIncreament(event){
        this.props.onIncrement();
    }

    onDecrement(event){
        this.props.onDecrement();

    }
    render() {
        return (
            <div>
             <button onClick={this.onIncreament}>+</button>  
             <button onClick={this.onDecrement}>-</button>        
            </div>
        );
    }
}

export default Button;