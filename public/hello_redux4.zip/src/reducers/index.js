import { combineReducers } from 'redux';
import counter from './counter';
import ui from './ui';
import vpa from './vpa';


const reducers = combineReducers({
    counter, ui,vpa
});

export default reducers;
