import * as types from '../actions/ActionTypes';

const initialState = {
    title:"vpa"
};

export default function vpa(state = initialState, action) {
    if(action.type === types.VPA) {
        return {
            title: state.title
        };
    } else {
        return state;
    }
}
