import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
//import registerServiceWorker from './registerServiceWorker';

import{createStore} from 'redux';
import counterApp from './reducers';

const store=createStore(counterApp);

ReactDOM.render(<App store={store} />, document.getElementById('root'));

const render=()=>{
    ReactDOM.render(
        <App store={store} />,document.getElementById('root') 
    );
}

store.subscribe(render);
render();
//registerServiceWorker();
